package com.example.newsapplication;

public class Retrofit {
}
